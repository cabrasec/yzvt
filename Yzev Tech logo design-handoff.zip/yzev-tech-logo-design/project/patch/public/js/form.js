/* ==========================================================================
   form.js — substitui public/js/form.js

   Base: a sua versão atual com Web3Forms (chave preservada).
   Três correções:
    1. os campos novos (budget, deadline) NÃO estavam no payload — os leads
       chegariam sem a informação de qualificação;
    2. fetch sem timeout: se a API não responder, o botão fica em "Enviando..."
       para sempre. Agora aborta em 15s e mostra o banner de erro;
    3. após enviar, o foco vai para o banner — leitor de tela anuncia o
       resultado (o banner também tem aria-live no ContactForm.astro).
   ========================================================================== */
(function () {
  "use strict";

  const WEB3FORMS_ACCESS_KEY = "41bfdaca-4693-4dcb-8dcb-376af9895ebc";
  const WEB3FORMS_ENDPOINT = "https://api.web3forms.com/submit";
  const TIMEOUT_MS = 15000;

  const form = document.getElementById("lead-form");
  if (!form) return;

  const fieldsWrap = document.getElementById("form-fields");
  const submitBtn = document.getElementById("form-submit");
  const successBanner = document.getElementById("form-success");
  const errorBanner = document.getElementById("form-error");

  const REQUIRED_FIELDS = ["name", "email", "whatsapp", "service", "message"];
  const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  const WHATSAPP_DIGITS_RE = /\d/g;

  let isSubmitting = false;

  function t(key, fallback) {
    var lang = document.documentElement.getAttribute("data-lang") || "pt";
    var dict = (window.YZEV_I18N && (window.YZEV_I18N[lang] || window.YZEV_I18N.pt)) || {};
    return dict[key] || fallback;
  }

  function fieldEl(name) {
    return form.querySelector('[data-field="' + name + '"]');
  }

  function setFieldError(name, message) {
    var wrap = fieldEl(name);
    if (!wrap) return;
    wrap.classList.toggle("has-error", !!message);
    var errorEl = wrap.querySelector(".field__error");
    if (errorEl) errorEl.textContent = message || "";
    var control = wrap.querySelector("input, select, textarea");
    if (control) {
      if (message) control.setAttribute("aria-invalid", "true");
      else control.removeAttribute("aria-invalid");
    }
  }

  function clearAllErrors() {
    REQUIRED_FIELDS.forEach(function (name) { setFieldError(name, ""); });
  }

  function validate() {
    var data = new FormData(form);
    var errors = {};

    var name = (data.get("name") || "").toString().trim();
    if (!name) errors.name = t("form.validation.required", "Preencha este campo.");

    var email = (data.get("email") || "").toString().trim();
    if (!email) {
      errors.email = t("form.validation.required", "Preencha este campo.");
    } else if (!EMAIL_RE.test(email)) {
      errors.email = t("form.validation.email", "Digite um e-mail válido.");
    }

    var whatsapp = (data.get("whatsapp") || "").toString().trim();
    var whatsappDigits = whatsapp.match(WHATSAPP_DIGITS_RE) || [];
    if (!whatsapp) {
      errors.whatsapp = t("form.validation.required", "Preencha este campo.");
    } else if (whatsappDigits.length < 8) {
      errors.whatsapp = t("form.validation.whatsapp", "Digite um WhatsApp válido.");
    }

    var service = (data.get("service") || "").toString().trim();
    if (!service) errors.service = t("form.validation.required", "Selecione uma opção.");

    var message = (data.get("message") || "").toString().trim();
    if (!message) errors.message = t("form.validation.required", "Preencha este campo.");

    return { errors: errors, data: data };
  }

  function setLoading(loading) {
    isSubmitting = loading;
    submitBtn.classList.toggle("is-loading", loading);
    submitBtn.disabled = loading;
    var label = submitBtn.querySelector(".btn__label");
    if (label) {
      label.textContent = loading
        ? t("form.submitting", "Enviando...")
        : t("form.submit", "Enviar solicitação");
    }
  }

  function showSuccess() {
    fieldsWrap.hidden = true;
    errorBanner.hidden = true;
    successBanner.hidden = false;
    if (typeof successBanner.focus === "function") successBanner.focus();
  }

  function showError() {
    errorBanner.hidden = false;
    if (typeof errorBanner.focus === "function") errorBanner.focus();
  }

  form.addEventListener("submit", function (e) {
    e.preventDefault();
    if (isSubmitting) return;

    clearAllErrors();
    errorBanner.hidden = true;

    var result = validate();
    var errorKeys = Object.keys(result.errors);

    if (errorKeys.length) {
      errorKeys.forEach(function (name) { setFieldError(name, result.errors[name]); });
      var firstField = fieldEl(errorKeys[0]);
      if (firstField) {
        var control = firstField.querySelector("input, select, textarea");
        if (control) control.focus();
      }
      return;
    }

    if ((result.data.get("botcheck") || "").toString()) {
      // Honeypot preenchido — descarta em silêncio (provável bot).
      showSuccess();
      return;
    }

    function val(key) {
      return (result.data.get(key) || "").toString().trim();
    }

    var payload = {
      access_key: WEB3FORMS_ACCESS_KEY,
      subject: "Novo contato via site YZEV Tech",
      from_name: "Site YZEV Tech",
      name: val("name"),
      email: val("email"),
      whatsapp: val("whatsapp"),
      company: val("company"),
      service: val("service"),
      budget: val("budget"),      // novo: investimento previsto
      deadline: val("deadline"),  // novo: prazo desejado
      message: val("message"),
      lang: document.documentElement.getAttribute("data-lang") || "pt",
      source: "website",
      createdAt: new Date().toISOString()
    };

    setLoading(true);

    var controller = typeof AbortController !== "undefined" ? new AbortController() : null;
    var timer = setTimeout(function () { if (controller) controller.abort(); }, TIMEOUT_MS);

    fetch(WEB3FORMS_ENDPOINT, {
      method: "POST",
      headers: { "Content-Type": "application/json", "Accept": "application/json" },
      body: JSON.stringify(payload),
      signal: controller ? controller.signal : undefined
    })
      .then(function (response) {
        return response.json().then(function (json) { return { ok: response.ok, json: json }; });
      })
      .then(function (res) {
        clearTimeout(timer);
        setLoading(false);
        if (res.ok && res.json && res.json.success) showSuccess();
        else showError();
      })
      .catch(function () {
        clearTimeout(timer);
        setLoading(false);
        showError();
      });
  });

  form.querySelectorAll("input, select, textarea").forEach(function (control) {
    control.addEventListener("input", function () {
      var wrap = control.closest(".field");
      if (wrap && wrap.classList.contains("has-error")) {
        wrap.classList.remove("has-error");
        control.removeAttribute("aria-invalid");
        var errorEl = wrap.querySelector(".field__error");
        if (errorEl) errorEl.textContent = "";
      }
    });
  });
})();
