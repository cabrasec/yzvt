# Patch YZEV Tech — o que aplicar

Repo: `cabrasec/yzvt`, branch `main`. Todos os arquivos abaixo espelham a
estrutura real do repositório. Copie por cima e commite.

## 1. Arquivos novos
| De | Para |
|---|---|
| `patch/src/components/WhatsAppFab.astro` | `src/components/WhatsAppFab.astro` |
| `patch/public/css/yzev-patch.css` | `public/css/yzev-patch.css` |
| `patch/public/js/i18n-extra.js` | `public/js/i18n-extra.js` |

## 2. Substituições
| De | Para |
|---|---|
| `patch/src/pages/index.astro` | `src/pages/index.astro` |
| `patch/src/components/AdditionalSections.astro` | `src/components/AdditionalSections.astro` |
| `patch/src/components/ContactForm.astro` | `src/components/ContactForm.astro` |
| `patch/src/components/Footer.astro` | `src/components/Footer.astro` |
| `patch/public/js/form.js` | `public/js/form.js` |

## 3. Três edições manuais em `src/layouts/BaseLayout.astro`

```diff
   <link rel="stylesheet" href="/css/style.css" />
+  <link rel="stylesheet" href="/css/yzev-patch.css" />
```

```diff
   <script is:inline src="/js/i18n.js"></script>
+  <script is:inline src="/js/i18n-extra.js"></script>
   <script is:inline src="/js/main.js"></script>
```

```diff
+---
+import WhatsAppFab from '../components/WhatsAppFab.astro';
+---
...
     <slot />
+    <WhatsAppFab />
```
(o `BaseLayout` já tem frontmatter — só acrescente o `import` nele)

## 4. `src/data/services.js`
Adicione `lead: true` em **um** serviço para ele ocupar o dobro de espaço na
grade. Sugestão: `microsaas-e-saas` (é o produto, não o serviço avulso). Sem
isso a grade fica igual à de hoje.

## 5. `src/data/projects.js`
Adicione `published: true` no projeto que tiver conteúdo real. Enquanto nenhum
tiver, a home mostra "Como trabalhamos" em vez dos três cards "Projeto em
preparação". Os três atuais são placeholders — deixe sem a flag.

## Mensagem de commit sugerida

```
feat(home): i18n completo, contato direto e revisão de conteúdo

- restaura data-i18n na home (EN/ES traduziam só o menu)
- adiciona botão flutuante do WhatsApp (aparece após 600px, some no formulário)
- cases vazios -> seção "Como trabalhamos" até haver case publicado
- copy diferenciada por seção; diferenciais 5 -> 4 cards
- rodapé com número do WhatsApp visível
- formulário: campos de investimento e prazo, aria-live/aria-invalid, timeout 15s
- corrige <dl> sem <dd> no hero, contraste do índice dos cards e scroll-padding
```

---

## Decisões tomadas por você não ter confirmado

- **E-mail:** removido do rodapé (ficou só WhatsApp). Para acrescentar depois,
  descomente o bloco em `Footer.astro` e preencha `EMAIL`.
- **Faixa de compromissos:** não entrou na página. As traduções seguem em
  `i18n-extra.js` (`proof.*`) e o markup está comentado no fim de `index.astro` —
  cole quando decidir quais promessas você sustenta.

## Já resolvido no repo (saiu da lista)

- Monograma: `public/img/yzev-monogram.svg` já é o Z de traço único, cantos
  vivos, sem animação infinita.
- Envio do formulário: já usa Web3Forms com chave real — o alerta do
  `N8N_WEBHOOK_URL` não se aplica mais.

## Ainda em aberto (fora deste patch)

- `og:image` e `apple-touch-icon` precisam de PNG (1200×630 e 180×180); SVG não
  renderiza em preview de WhatsApp/LinkedIn nem como ícone iOS.
- Sem `canonical`, `robots.txt`, `sitemap.xml` nem JSON-LD `Organization`.
- Menu mobile não prende o foco nem devolve ao botão ao fechar.
- Menu de idioma tem `role="listbox"` sem navegação por teclado.
- `main.js` ignora `navigator.language` no primeiro acesso — visitante de fora
  cai em PT mesmo sem preferência salva. (Relevante para os amigos no exterior.)
- Três idiomas na mesma URL: EN/ES não são indexados. Para busca nesses idiomas
  seria preciso `/en/` e `/es/` com `hreflang`.
