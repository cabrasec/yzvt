repo: cabrasec/yzvt
branch: main

## Last sync

date: 2026-10-07T00:18:57Z

### Updated in this project

- Upstream migrou de Astro para Next.js (App Router + Tailwind) — os arquivos `.astro` e `public/js/*` mapeados antes não existem mais
- `BrandMark.tsx` já usa exatamente o Z do Logo System (paths e gradientes idênticos) — nada a reconstruir
- `patch/` ficou obsoleto (alvos deletados no upstream); mantido só como referência
- Tokens de `globals.css` conferem com a paleta do Logo System

## Screen map

| Tela do projeto | Arquivos no repo |
|---|---|
| `Yzev Logo System.dc.html` | `src/components/brand/BrandMark.tsx`, `src/components/brand/Logo.tsx`, `src/styles/globals.css` |
| `Yzev Site Blueprint.dc.html` | `src/components/Hero.tsx`, `src/components/hero/BlueprintMark.tsx`, `src/components/Process.tsx`, `src/styles/globals.css` |
| `Instagram Profile.dc.html` | — (sem equivalente no repo) |
| `patch/` (obsoleto) | alvos Astro removidos upstream |

## Sync history

### 2026-08-27T15:29:32Z
- Patch da home preparado em `patch/` para a versão Astro (i18n, FAB do WhatsApp, "Como trabalhamos", formulário qualificado)
- Monograma e envio via Web3Forms confirmados como resolvidos naquela versão
