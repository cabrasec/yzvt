// Só para este preview: reveal-on-scroll + validação/estado do formulário.
// No site real isso já vive em js/main.js e js/form.js — a única coisa que
// vale copiar daqui é o bloco marcado FORM (validação + estados do botão).
(function () {
  var io = new IntersectionObserver(function (entries) {
    entries.forEach(function (e) {
      if (e.isIntersecting) { e.target.classList.add('is-visible'); io.unobserve(e.target); }
    });
  }, { rootMargin: '0px 0px -12% 0px', threshold: 0.12 });
  document.querySelectorAll('.reveal').forEach(function (el) { io.observe(el); });

  var y = document.getElementById('year');
  if (y) y.textContent = new Date().getFullYear();

  // ---------- FORM ----------
  var form = document.getElementById('lead-form');
  if (!form) return;
  var fields = document.getElementById('form-fields');
  var btn = document.getElementById('form-submit');
  var ok = document.getElementById('form-success');
  var err = document.getElementById('form-error');

  var MSG = {
    required: 'Preencha este campo.',
    email: 'Informe um e-mail válido.',
    phone: 'Informe um telefone com DDD.'
  };

  function setError(wrap, msg) {
    wrap.classList.toggle('has-error', !!msg);
    var slot = wrap.querySelector('.field__error');
    if (slot) slot.textContent = msg || '';
  }

  function validate() {
    var valid = true;
    form.querySelectorAll('.field[data-field]').forEach(function (wrap) {
      var input = wrap.querySelector('input, select, textarea');
      if (!input || !input.required) { setError(wrap, ''); return; }
      var v = (input.value || '').trim();
      var msg = '';
      if (!v) msg = MSG.required;
      else if (input.type === 'email' && !/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(v)) msg = MSG.email;
      else if (input.type === 'tel' && v.replace(/\D/g, '').length < 10) msg = MSG.phone;
      if (msg) valid = false;
      setError(wrap, msg);
    });
    return valid;
  }

  form.addEventListener('input', function (e) {
    var wrap = e.target.closest('.field');
    if (wrap && wrap.classList.contains('has-error')) setError(wrap, '');
  });

  form.addEventListener('submit', function (e) {
    e.preventDefault();
    err.hidden = true;
    if (!validate()) {
      var first = form.querySelector('.has-error input, .has-error select, .has-error textarea');
      if (first) first.focus();
      return;
    }
    btn.classList.add('is-loading');
    // No site: POST para N8N_WEBHOOK_URL com new FormData(form).
    setTimeout(function () {
      btn.classList.remove('is-loading');
      fields.hidden = true;
      ok.hidden = false;
    }, 900);
  });
})();
