# Prompts para o Canva — explorar, não copiar

O problema do prompt anterior: ele descrevia o meu desenho traço por traço, então
o Canva não tinha o que inventar. Estes prompts fazem o contrário — fixam só o que
é identidade e **abrem** o que é decisão de desenho.

---

## Fixo (nunca mude)

Cole este bloco no começo de qualquer prompt:

> Marca: YZEV Tech — software sob medida, MicroSaaS, automação com IA e
> infraestrutura, no Brasil. Personalidade técnica, precisa, futurista.
> Restrições: fundo escuro, uma única cor de acento, tipografia sem serifa de
> grotesca neutra, nenhum gradiente colorido, nenhum brilho, nenhum ícone de
> engrenagem, circuito, robô, lâmpada, globo, nuvem ou foguete, nenhum emoji.
> Contraste vem do tom, não da saturação.

---

## Livre (é aqui que ele deve inventar)

Diga explicitamente que estes eixos estão abertos:

> Livre para propor: a lógica de construção do símbolo, o peso e o recorte da
> tipografia, a relação entre símbolo e palavra, a temperatura exata do acento, o
> sistema de layout e a textura de fundo.

---

## Prompt 1 — divergir no símbolo

> A partir da referência anexada, crie **seis** símbolos para a YZEV Tech, cada
> um com uma lógica de construção diferente. Não repita a solução da referência.
>
> Uma por abordagem:
> 1. letra Z construída por subtração — a forma surge do espaço negativo entre blocos
> 2. Z como caminho contínuo de um único traço, sem começo nem fim visível
> 3. Y e Z sobrepostos num só sinal
> 4. forma abstrata derivada de um nó de rede ou rota de dados, sem ser letra
> 5. símbolo modular construído por uma grade de quadrados de tamanho igual
> 6. marca tipográfica: o símbolo é uma letra do próprio logotipo, redesenhada
>
> Cada um em uma variante só, monocromático, sobre fundo escuro. Mostre os seis
> lado a lado no mesmo tamanho.

---

## Prompt 2 — divergir na tipografia

> Desenhe **quatro** logotipos para a palavra "yzevtech", cada um com um
> tratamento tipográfico distinto: (a) caixa baixa com espaçamento negativo e
> terminais cortados na horizontal; (b) caixa alta com tracking muito largo e
> corpo pequeno; (c) letras com cortes de estêncil — vãos que interrompem os
> traços; (d) largura condensada, altura-x alta, sem símbolo nenhum.
> Sem símbolo acompanhando. Fundo escuro, uma cor de acento.

---

## Prompt 3 — divergir no acento

> Mesma marca, cinco versões da paleta: mantenha o fundo escuro e troque só o
> acento — um violeta, um ciano frio, um verde-limão técnico, um âmbar, e um
> monocromático sem acento (só claro sobre escuro). Mostre cada paleta como seis
> tons e aplique o logotipo em cada uma.

---

## Prompt 4 — divergir no sistema

> Crie **três** sistemas visuais completos para a YZEV Tech, cada um com uma
> estética própria e coerente do começo ao fim:
> 1. **Terminal** — grade monoespaçada visível, réguas finas, densidade alta,
>    estética de ferramenta de desenvolvedor
> 2. **Editorial** — tipografia grande, muito espaço vazio, assimetria, quase
>    nada de elemento gráfico
> 3. **Blueprint** — linhas de construção, cotas, marcas de registro, estética
>    de desenho técnico
>
> Para cada sistema: logotipo, ícone, cartão de visita e um post 1080×1080.
> Os três devem parecer de empresas diferentes.

---

## Prompt 5 — quebrar o padrão de propósito

Quando ele ainda estiver repetindo:

> Isto está parecido demais com a referência. Gere uma alternativa que
> deliberadamente contrarie três decisões dela: use fundo claro em vez de escuro,
> tipografia com serifa em vez de grotesca, e nenhum símbolo — só palavra.
> Mantenha apenas o nome e a personalidade técnica.

---

## Como conduzir

1. Rode o Prompt 1 e escolha **dois** símbolos — não o melhor, os dois mais diferentes entre si.
2. Rode o Prompt 2 só com esses dois, para achar a palavra certa para cada.
3. Rode o Prompt 4 com o par vencedor. Aí você tem sistema, não logo.
4. Quando ele repetir, use o Prompt 5. Contrariar é mais eficiente do que pedir "mais criativo".

**A frase que mais funciona:** *"não repita a referência — ela é o ponto de partida,
não o alvo"*. E peça sempre número ímpar de opções acima de quatro; abaixo disso o
Canva entrega variações da mesma ideia.
